# LGen — Landing / Image / Video / Text Generator

> ⚠️ **Обновление (исправление генерации медиа).** Раньше работали только текст и
> лендинг: в режимах «картинка», «видео», «изменить фото» и «оживить фото» промпт
> не отправлялся (модалка Terms of Use блокировала composer, а Enter «съедался»
> ей же), а результат не забирался (искали текстовую кнопку «Download», хотя в
> карточке результата Arena это иконка).
> Что именно исправлено и как это проверить — **[FIXES.ru.md](FIXES.ru.md)**.

AI-генератор контента через Arena.ai. Включает:
- 🤖 **Telegram Bot** — для пользователей
- 🌐 **REST API** — для интеграций / автоматизации

## 📂 Структура проекта

```
LGen/
├── bot.py               # Telegram Bot (aiogram 3)
├── api_server.py        # REST API (FastAPI)
├── arena_generator.py   # Playwright-обёртка над arena.ai
├── config.py            # Конфигурация
├── database.py          # SQLite база
├── admin.py             # Админ-функции
├── payments.py          # Платежи (CryptoBot / Platega)
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
├── API_DOCS.md          # ← Полная документация API
└── cookies/
    └── arena_cookies.json
```

## ✅ Проверка после обновления

```bash
# быстрые офлайн-тесты (без браузера)
pytest -q tests/

# офлайн-прогон реального конвейера в Chromium против локального мока arena.ai
# (модалка Terms of Use, textarea, Send message, Stop generation, карточка результата)
python selftest_arena.py            # все режимы
python selftest_arena.py image      # только картинка
python selftest_arena.py video      # только видео
```

## 🚀 Быстрый старт (локально)

```bash
pip install -r requirements.txt
playwright install chromium

cp .env.example .env
# Отредактируйте .env

mkdir -p cookies generated

# Необязательно: несколько профилей cookies (*.json) в cookies/ и прокси
# (по одному адресу на строку) в proxies/*.txt. При HTTP 429 будет выбрана
# следующая пара и текущая операция повторится один раз.
mkdir -p proxies

# 🌟 Запуск всего одной командой (Бот + REST API одновременно):
python run.py

# Или раздельно (при необходимости):
python run.py --bot          # только Telegram-бот
python run.py --api          # только REST API сервер
```

## Google Login and Cookie Import

Use only Google accounts you own or are authorized to use. Install the dependencies
and Chromium as shown above. Create `credentials/google_accounts.txt` locally with
one account per line. The separator is a **literal TAB**, not a colon, comma, or
the characters `\t`:

```text
# Email-only: complete the password and security steps in the browser
first@gmail.com
# Email<TAB>password: ordinary email/password fields can be filled automatically
second@gmail.com	YOUR_PASSWORD
```

Empty lines and lines starting with `#` are ignored. Passwords may contain colons
or spaces; everything after the first TAB is the password. Duplicate emails are
rejected. Ten accounts means ten lines; accounts run sequentially in isolated
browser sessions. Email-only accounts also have their ordinary email field filled.

```bash
# Standalone cookie collection, without importing bot/API configuration
python bootstrap_google.py --accounts credentials/google_accounts.txt --timeout 300

# Collect first, then launch; any failed account prevents service startup
python run.py --bootstrap-google --google-accounts credentials/google_accounts.txt
python run.py --api --bootstrap-google
```

The browser is headed by default. Complete MFA, CAPTCHA, Google consent, Arena
terms, or blocked/changed login screens **manually** within the per-account timeout.
If login buttons cannot be located, click them manually. After returning to Arena,
open its account menu so both your exact account email and **Log out / Sign out**
are visible. Export requires those authenticated controls on `https://arena.ai`
and nonempty Arena cookies; simply reaching the homepage is not enough. The script
does not bypass security checks, use stealth, or guarantee Google automation.
`--headless` (or `ARENA_GOOGLE_HEADLESS=1`) removes manual completion and is only
appropriate when the normal flow needs no intervention. A desktop/display is
required for headed operation; Docker/VPS deployments usually collect locally first.

Successful accounts produce `cookies/google_<email-hash>.json` (or `COOKIES_DIR`),
containing only cookies applicable to Arena, not Google cookies. Files are replaced
atomically only after verification; failed accounts leave existing exports intact.
Successful exports remain available if a later account fails. The generator already
discovers these JSON files; no copy into `arena_cookies.json` is needed. Remove stale
cookie profiles yourself if they should no longer participate in the pool. For
manual import, export a Playwright cookie array (or an object with a `cookies` array)
into a `*.json` file under `COOKIES_DIR` before launching services.

Proxies are read from sorted `PROXIES_DIR/*.txt` and `*.list`, one URL per line,
using the existing pool format `scheme://[user:password@]host:port` (default HTTP).
IPv6 and percent-encoded credentials are supported. Authenticated SOCKS5 uses a
runtime local SOCKS5 forwarding bridge (`python-socks`), shared by the generator
and bootstrap. Chromium connects without credentials to an ephemeral port bound
only to `127.0.0.1`; the bridge authenticates to the configured upstream SOCKS5
proxy and resolves destination names upstream. No public listener, separate daemon,
or direct-network fallback is used. Other local processes can access the loopback
port while it runs, so use a trusted host. The bridge closes with the browser,
including failed initialization and rotation. HTTP/HTTPS authentication and
unauthenticated SOCKS5 continue to use Chromium's native proxy support.

After copying updated `arena_generator.py`, `bootstrap_google.py`,
`browser_proxy.py`, and `requirements.txt` to Linux, run
`python -m pip install -r requirements.txt` in the service's virtual environment
and restart the service (`python run.py` for a foreground deployment).
Docker deployments must rebuild with `docker compose up -d --build`.

Bootstrap maps the normalized email hash to
a proxy consistently while the ordered proxy pool is unchanged. **Runtime rotation
is unchanged and may choose a different proxy**; this is not persistent runtime
account/proxy affinity. If matching egress is required, use a single proxy pool entry.

`credentials/`, default cookie/proxy directories, and `.env` are ignored. Custom
credential/output paths must be excluded from version control yourself. Cookies
are login secrets; restrict filesystem access (including Windows ACLs), never
commit them, and do not share the TXT file. Passwords and proxy credentials are
not logged. The bootstrap does not persist browser profiles or screenshots.

## 🐳 Деплой на VPS (Docker)

```bash
# Настроить .env
cp .env.example .env && nano .env

# Добавить cookies/arena_cookies.json

# Запустить всё
docker compose up -d --build
```

- API доступен на `http://YOUR_VPS:8000`
- Swagger UI: `http://YOUR_VPS:8000/docs`

## 📡 API — режимы генерации

| Endpoint | Режим Arena | Описание |
|----------|-------------|----------|
| `POST /generate/code` | code/direct | Лендинг (ZIP/HTML) |
| `POST /generate/text` | text/direct | Текстовый ответ |
| `POST /generate/prompt` | text/direct | Генерация промта по теме |
| `POST /generate/image` | image/direct | Изображение (PNG) |
| `POST /edit/image` | image/direct | Редактирование фото (multipart) |
| `POST /animate/image` | video | Оживление фото → 2 видео |
| `POST /generate/video` | video | 2 видео-варианта |
| `GET /download?path=` | — | Скачать файл |
| `GET /files` | — | Список файлов |
| `GET /health` | — | Статус |

→ Подробная документация: **[API_DOCS.md](API_DOCS.md)**

## 🔐 Авторизация API

Все запросы (кроме `/health`) требуют заголовка:
```
X-API-Key: your_api_secret
```
Ключ настраивается в `.env` → `API_SECRET`.
