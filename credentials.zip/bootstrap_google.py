"""Collect Arena cookies through ordinary Google sign-in, with manual fallback."""

import argparse
import asyncio
from contextvars import ContextVar
from dataclasses import dataclass, field
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import re
import tempfile
from urllib.parse import quote, unquote, urlparse

from browser_proxy import BrowserProxy, playwright_proxy

from dotenv import load_dotenv
from playwright.async_api import async_playwright, Error as PlaywrightError

logger = logging.getLogger("Arena-Bootstrap")
ARENA_URL = "https://arena.ai/"
_stage = ContextVar("bootstrap_stage", default="launch")


class BootstrapFailure(RuntimeError):
    def __init__(self, stage, detail, systemic=False):
        super().__init__(detail)
        self.stage = stage
        self.systemic = systemic


def safe_detail(exc, accounts=(), proxies=()):
    """Redact before truncating; never log raw exceptions or their traceback."""
    text = str(exc)
    secrets = set()
    for account in accounts:
        secrets.update((account.email, account.password))
    for proxy in proxies:
        secrets.add(proxy)
        try:
            parsed = urlparse(proxy if "://" in proxy else "http://" + proxy)
            secrets.update((unquote(parsed.username or ""), unquote(parsed.password or "")))
        except ValueError:
            pass
    variants = {variant for secret in secrets if secret
                for variant in (secret, quote(secret, safe=""), repr(secret)[1:-1])}
    for secret in sorted(variants, key=len, reverse=True):
        text = re.sub(re.escape(secret), "[redacted]", text, flags=re.I)
    text = re.sub(r"(?i)\b((?:https?|socks5)://)[^\s/]+@", r"\1[redacted]@", text)
    text = re.sub(r"(?i)\b[^\s/:]+:[^\s/@]+@(?=[\w\[])", "[redacted]@", text)
    # URL queries/fragments can contain OAuth tokens, even without userinfo.
    text = re.sub(r"(https?://[^\s?#]+)[?#][^\s]+", r"\1[redacted]", text)
    return " ".join(text.split())[:2000] or "No exception detail provided"


def systemic_launch_error(exc):
    text = str(exc).lower()
    return any(marker in text for marker in (
        "executable doesn't exist", "executable does not exist",
        "host system is missing dependencies", "error while loading shared libraries",
        "playwright install", "missing dependencies to run browsers"))


@dataclass(frozen=True)
class Account:
    email: str
    password: str = field(default="", repr=False)

    @property
    def key(self):
        return hashlib.sha256(self.email.lower().encode("utf-8")).hexdigest()[:24]


def read_accounts(path):
    accounts = []
    seen = set()
    for number, raw in enumerate(Path(path).read_text(encoding="utf-8-sig").splitlines(), 1):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        email, separator, password = raw.partition("\t")
        email = email.strip().lower()
        if not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+", email):
            raise ValueError(f"Invalid account format at line {number}; use email<TAB>password or email")
        if email in seen:
            raise ValueError(f"Duplicate account at line {number}")
        seen.add(email)
        accounts.append(Account(email, password if separator else ""))
    if not accounts:
        raise ValueError("Accounts file is empty")
    return accounts


def read_proxies(directory):
    root = Path(directory)
    proxies = []
    if root.is_dir():
        for path in sorted(root.iterdir()):
            if path.is_file() and path.suffix.lower() in (".txt", ".list"):
                proxies.extend(line.strip() for line in path.read_text(encoding="utf-8").splitlines()
                               if line.strip() and not line.lstrip().startswith("#"))
    return proxies


def account_proxy(account, proxies):
    return proxies[int(account.key, 16) % len(proxies)] if proxies else None


def atomic_export(path, cookies):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix=".bootstrap-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(cookies, stream, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


async def click_visible(locator):
    locator = locator.first
    if await locator.is_visible():
        await locator.click(timeout=1500)
        return True
    return False


async def arena_authenticated(page, email):
    """Fail closed: anonymous cookies, a callback URL, or a composer are not proof."""
    parsed = urlparse(page.url)
    if parsed.scheme != "https" or parsed.hostname != "arena.ai" or parsed.path.startswith("/auth"):
        return False
    logout = page.get_by_role("menuitem", name=re.compile(r"^(log out|sign out)$", re.I)).or_(
        page.get_by_role("button", name=re.compile(r"^(log out|sign out)$", re.I)))
    identity = page.get_by_text(email, exact=True)
    return await logout.first.is_visible() and await identity.first.is_visible()


async def login_account(context, account):
    _stage.set("context")
    page = await context.new_page()
    _stage.set("navigation")
    await page.goto(ARENA_URL, wait_until="domcontentloaded", timeout=30000)
    _stage.set("manual login")
    submitted = set()
    clicked = set()
    logger.info("Account %s: complete any security checks manually; open the Arena account menu after login", account.key)
    while True:
        for current in list(context.pages):
            if current.is_closed():
                continue
            try:
                if await arena_authenticated(current, account.email):
                    cookies = await context.cookies([ARENA_URL])
                    if cookies:
                        return cookies
                parsed = urlparse(current.url)
                if parsed.scheme == "https" and parsed.hostname == "accounts.google.com":
                    # Only normal identifier/password steps. Challenges and consent stay manual.
                    if "/challenge/" in parsed.path and not parsed.path.endswith("/challenge/pwd"):
                        continue
                    for step, selector, value, next_selector in (
                        ("email", 'input[type="email"]', account.email, "#identifierNext"),
                        ("password", 'input[type="password"]', account.password, "#passwordNext"),
                    ):
                        control = current.locator(selector).first
                        if value and step not in submitted and await control.is_visible():
                            await control.fill(value, timeout=1500)
                            submitted.add(step)
                            await click_visible(current.locator(next_selector))
                elif parsed.scheme == "https" and parsed.hostname == "arena.ai":
                    for step, pattern in (
                        ("login", r"^(sign in|log in|login|sign up / log in)$"),
                        ("google", r"^(continue with google|sign in with google|google)$"),
                        ("profile", r"^(user menu|account menu|profile|my account)$"),
                    ):
                        if step not in clicked:
                            controls = current.get_by_role("button", name=re.compile(pattern, re.I)).or_(
                                current.get_by_role("link", name=re.compile(pattern, re.I)))
                            if await click_visible(controls):
                                clicked.add(step)
            except PlaywrightError:
                # Navigations can detach controls. Never print browser errors containing secrets.
                continue
        if not context.pages:
            raise RuntimeError("Browser pages closed before verified login")
        await asyncio.sleep(0.5)


async def collect_account(playwright, account, proxies, output, headless, *, keep_open_on_error=0):
    token = _stage.set("proxy setup")
    browser = None
    try:
        async with BrowserProxy(account_proxy(account, proxies)) as proxy:
            try:
                options = {"headless": headless}
                if proxy:
                    options["proxy"] = proxy
                _stage.set("launch")
                browser = await playwright.chromium.launch(**options)
                _stage.set("context")
                context = await browser.new_context(locale="en-US")
                cookies = await login_account(context, account)
                _stage.set("export")
                atomic_export(Path(output) / f"google_{account.key}.json", cookies)
            except (Exception, asyncio.CancelledError) as exc:
                stage = _stage.get()
                detail = ("Per-account timeout expired or operation cancelled" if isinstance(exc, asyncio.CancelledError)
                          else "Cookie export failed; check output directory permissions and disk space" if stage == "export"
                          else safe_detail(exc, [account], proxies))
                logger.error("Account %s: stage=%s failed (%s): %s; existing cookies left unchanged",
                             account.key, stage, type(exc).__name__, detail)
                if browser is not None and not headless and keep_open_on_error:
                    logger.info("Account %s: keeping failed browser open for %s seconds; no screenshots or traces saved",
                                account.key, keep_open_on_error)
                    await asyncio.sleep(keep_open_on_error)
                if isinstance(exc, asyncio.CancelledError):
                    raise
                raise BootstrapFailure(stage, detail, stage == "launch" and systemic_launch_error(exc)) from None
            finally:
                if browser is not None:
                    await browser.close()
    except BootstrapFailure:
        raise
    except Exception as exc:
        raise BootstrapFailure(_stage.get(), safe_detail(exc, [account], proxies)) from None
    finally:
        _stage.reset(token)


async def bootstrap(accounts_file=None, *, timeout=None, headless=None, limit=None, keep_open_on_error=0):
    load_dotenv()
    accounts_file = accounts_file or os.getenv("ARENA_GOOGLE_ACCOUNTS_FILE", "credentials/google_accounts.txt")
    timeout = float(timeout if timeout is not None else os.getenv("ARENA_GOOGLE_LOGIN_TIMEOUT", "300"))
    if not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("Login timeout must be a finite positive number of seconds")
    if not math.isfinite(keep_open_on_error) or not 0 <= keep_open_on_error <= 300:
        raise ValueError("Keep-open duration must be between 0 and 300 seconds")
    if limit is not None and (not isinstance(limit, int) or isinstance(limit, bool) or limit <= 0):
        raise ValueError("Account limit must be a positive integer")
    if headless is None:
        headless = os.getenv("ARENA_GOOGLE_HEADLESS", "0").strip().lower() in ("1", "true", "yes")
    accounts = read_accounts(accounts_file)
    if limit is not None:
        accounts = accounts[:limit]
    proxies = read_proxies(os.getenv("PROXIES_DIR", "proxies"))
    for proxy in proxies:
        playwright_proxy(proxy)
    failures = 0
    attempted = 0
    async with async_playwright() as playwright:
        for account in accounts:
            attempted += 1
            try:
                options = {"keep_open_on_error": keep_open_on_error} if keep_open_on_error else {}
                await asyncio.wait_for(collect_account(
                    playwright, account, proxies, os.getenv("COOKIES_DIR", "cookies"), headless, **options), timeout)
                logger.info("Account %s: verified cookies saved", account.key)
            except Exception as exc:
                failures += 1
                detail = (safe_detail(exc, accounts, proxies) if isinstance(exc, BootstrapFailure)
                          else "Per-account timeout expired" if isinstance(exc, asyncio.TimeoutError)
                          else "Unexpected collector failure; detail suppressed for credential safety")
                logger.error("Account %s: bootstrap failed (%s): %s; existing cookies left unchanged",
                             account.key, type(exc).__name__, detail)
                if isinstance(exc, BootstrapFailure) and exc.systemic:
                    logger.error("Systemic Chromium launch failure: stopping remaining accounts. "
                                 "For a missing executable run: python -m playwright install chromium; "
                                 "for dependency errors repair the browser runtime installation.")
                    break
                logger.info("Troubleshooting: use --limit 1 --keep-open-on-error 60 (headed mode); "
                            "navigation errors may indicate unreachable proxy, DNS, TLS, or network failure")
    if failures:
        raise RuntimeError(f"Google bootstrap failed for {failures}/{attempted} attempted accounts; startup stopped")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--accounts", help="TXT file: email or email<TAB>password per line")
    parser.add_argument("--timeout", type=float, help="Per-account total timeout in seconds")
    parser.add_argument("--headless", action="store_true", default=None, help="No window; manual completion unavailable")
    parser.add_argument("--limit", type=int, help="Diagnose only the first N accounts (e.g. 1)")
    parser.add_argument("--keep-open-on-error", type=float, default=0, metavar="SECONDS",
                        help="Keep a failed headed browser open for 0-300 seconds before cleanup; no screenshots")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    try:
        asyncio.run(bootstrap(args.accounts, timeout=args.timeout, headless=args.headless,
                              limit=args.limit, keep_open_on_error=args.keep_open_on_error))
    except Exception as exc:
        logger.error("Bootstrap stopped (%s); check configuration or complete sign-in in the browser", type(exc).__name__)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
