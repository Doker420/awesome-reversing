"""Chromium proxy configuration and loopback authenticated SOCKS5 forwarding."""

import asyncio
from contextlib import suppress
import ipaddress
from urllib.parse import unquote, urlparse

from python_socks import ProxyType
from python_socks.async_.asyncio import Proxy


def playwright_proxy(value):
    """Parse without including credentials in validation errors."""
    try:
        parsed = urlparse(value if "://" in value else "http://" + value)
        if (parsed.scheme not in ("http", "https", "socks5") or not parsed.hostname
                or not parsed.port or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
            raise ValueError()
        host = f"[{parsed.hostname}]" if ":" in parsed.hostname else parsed.hostname
        result = {"server": f"{parsed.scheme}://{host}:{parsed.port}"}
        if parsed.username is not None:
            result.update(username=unquote(parsed.username), password=unquote(parsed.password or ""))
            if parsed.scheme == "socks5" and any(
                    not 1 <= len(result[key].encode("utf-8")) <= 255 for key in ("username", "password")):
                raise ValueError()
        return result
    except ValueError:
        raise ValueError("Invalid proxy; use scheme://[user:password@]host:port") from None


async def close_writer(writer):
    writer.close()
    with suppress(Exception):
        await asyncio.wait_for(writer.wait_closed(), 5)


class BrowserProxy:
    """Own the optional bridge on the caller's event loop; never fall back to direct."""

    def __init__(self, value, timeout=15):
        self.options = playwright_proxy(value) if value else None
        self.timeout = timeout
        self.server = None
        self.tasks = set()
        self.closing = False
        self.upstream = None

    async def start(self):
        if self.options and self.options["server"].startswith("socks5://") and "username" in self.options:
            parsed = urlparse(self.options["server"])
            self.upstream = Proxy(ProxyType.SOCKS5, parsed.hostname, parsed.port,
                                  username=self.options["username"], password=self.options["password"], rdns=True)
            self.server = await asyncio.start_server(self._accept, "127.0.0.1", 0)
            return {"server": f"socks5://127.0.0.1:{self.server.sockets[0].getsockname()[1]}"}
        return self.options

    def _accept(self, reader, writer):
        task = asyncio.create_task(self._serve(reader, writer))
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
        if self.closing:
            writer.close()

    async def _handshake(self, reader, writer):
        version, count = await reader.readexactly(2)
        if version != 5 or not count:
            raise ValueError("Invalid SOCKS greeting")
        methods = await reader.readexactly(count)
        writer.write(b"\x05\x00" if 0 in methods else b"\x05\xff")
        await writer.drain()
        if 0 not in methods:
            raise ValueError("Local SOCKS requires no authentication")
        version, command, reserved, kind = await reader.readexactly(4)
        if version != 5 or command != 1 or reserved != 0:
            raise ValueError("Only SOCKS5 CONNECT is supported")
        if kind == 3:
            length = (await reader.readexactly(1))[0]
            if not length:
                raise ValueError("Empty destination")
            host = (await reader.readexactly(length)).decode("idna")
        elif kind in (1, 4):
            host = str(ipaddress.ip_address(await reader.readexactly(4 if kind == 1 else 16)))
        else:
            raise ValueError("Invalid destination type")
        port = int.from_bytes(await reader.readexactly(2), "big")
        if not port:
            raise ValueError("Invalid destination port")
        return await self.upstream.connect(dest_host=host, dest_port=port, timeout=self.timeout)

    async def _serve(self, reader, writer):
        upstream_writer = None
        sock = None
        pipes = []
        connected = False
        try:
            if self.closing:
                return
            sock = await asyncio.wait_for(self._handshake(reader, writer), self.timeout)
            upstream_reader, upstream_writer = await asyncio.open_connection(sock=sock)
            sock = None  # ownership transferred to the stream transport
            writer.write(b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00")
            await writer.drain()
            connected = True

            async def pipe(source, target):
                while True:
                    data = await source.read(65536)
                    if not data:
                        if target.can_write_eof():
                            target.write_eof()
                            await target.drain()
                        return
                    target.write(data)
                    await target.drain()

            pipes = [asyncio.create_task(pipe(reader, upstream_writer)),
                     asyncio.create_task(pipe(upstream_reader, writer))]
            await asyncio.gather(*pipes)
        except Exception:
            # No exception text: upstream libraries may include proxy details.
            if not connected:
                with suppress(Exception):
                    writer.write(b"\x05\x01\x00\x01\x00\x00\x00\x00\x00\x00")
                    await asyncio.wait_for(writer.drain(), self.timeout)
        finally:
            for task in pipes:
                task.cancel()
            if pipes:
                await asyncio.gather(*pipes, return_exceptions=True)
            if sock is not None:
                sock.close()
            if upstream_writer is not None:
                await close_writer(upstream_writer)
            await close_writer(writer)

    async def close(self):
        self.closing = True
        if self.server is not None:
            self.server.close()
            await self.server.wait_closed()
            self.server = None
        tasks = list(self.tasks)
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        self.tasks.clear()

    async def __aenter__(self):
        try:
            return await self.start()
        except BaseException:
            await self.close()
            raise

    async def __aexit__(self, *args):
        await self.close()
