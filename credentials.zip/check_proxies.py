"""Bounded SOCKS5 diagnostics. Read credentials from disk; print only endpoint/status."""

import argparse
import asyncio
import ssl
import time
from pathlib import Path
from urllib.parse import unquote, urlparse


async def check_proxy(value, timeout=12):
    result = {"endpoint": "invalid", "tcp": False, "auth": False,
              "connect": False, "https": False, "status": "invalid configuration"}
    writer = None
    started = time.monotonic()
    try:
        parsed = urlparse(value)
        if parsed.scheme != "socks5" or not parsed.hostname or not parsed.port:
            return result
        result["endpoint"] = f"{parsed.hostname}:{parsed.port}"
        username = unquote(parsed.username or "").encode()
        password = unquote(parsed.password or "").encode()
        if not 0 < len(username) <= 255 or not 0 < len(password) <= 255:
            return result
        async with asyncio.timeout(timeout):
            result["status"] = "TCP connection failed"
            reader, writer = await asyncio.open_connection(parsed.hostname, parsed.port)
            result["tcp"] = True
            result["status"] = "SOCKS5 auth method unavailable"
            writer.write(b"\x05\x01\x02")
            await writer.drain()
            if await reader.readexactly(2) != b"\x05\x02":
                return result
            result["status"] = "SOCKS5 authentication rejected"
            writer.write(b"\x01" + bytes([len(username)]) + username
                         + bytes([len(password)]) + password)
            await writer.drain()
            if await reader.readexactly(2) != b"\x01\x00":
                return result
            result["auth"] = True
            result["status"] = "SOCKS5 CONNECT failed"
            host = b"www.google.com"
            writer.write(b"\x05\x01\x00\x03" + bytes([len(host)]) + host + b"\x01\xbb")
            await writer.drain()
            version, reply, reserved, kind = await reader.readexactly(4)
            if version != 5 or reserved != 0 or reply != 0:
                result["status"] = f"SOCKS5 CONNECT rejected (code {reply})"
                return result
            if kind == 1:
                await reader.readexactly(4)
            elif kind == 4:
                await reader.readexactly(16)
            elif kind == 3:
                await reader.readexactly((await reader.readexactly(1))[0])
            else:
                return result
            await reader.readexactly(2)
            result["connect"] = True
            result["status"] = "TLS/HTTPS failed"
            transport = writer.transport
            protocol = transport.get_protocol()
            transport = await writer.start_tls(ssl.create_default_context(), server_hostname=host.decode())
            if transport is not None:
                writer = asyncio.StreamWriter(transport, protocol, reader, asyncio.get_running_loop())
            writer.write(b"HEAD / HTTP/1.1\r\nHost: www.google.com\r\nConnection: close\r\n\r\n")
            await writer.drain()
            line = await reader.readline()
            fields = line.split()
            if len(fields) >= 2 and fields[0] in (b"HTTP/1.0", b"HTTP/1.1") and fields[1].isdigit():
                result["https"] = True
                result["status"] = f"HTTPS reachable (HTTP {int(fields[1])})"
    except TimeoutError:
        result["status"] += " (timeout)"
    except AttributeError:
        result["status"] = "TLS unsupported by this Python runtime"
    except Exception as exc:
        # Exception messages may contain credentials or remote content.
        result["status"] += f" ({type(exc).__name__})"
    finally:
        result["seconds"] = round(time.monotonic() - started, 2)
        if writer is not None:
            writer.close()
            try:
                await asyncio.wait_for(writer.wait_closed(), 1)
            except Exception:
                pass
    return result


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--file", default="proxies/pool.txt")
    args = parser.parse_args()
    values = [line.strip() for line in Path(args.file).read_text(encoding="utf-8").splitlines()
              if line.strip() and not line.lstrip().startswith("#")]
    results = await asyncio.gather(*(check_proxy(value) for value in values))
    for result in results:
        stages = " ".join(f"{stage}={'ok' if result[stage] else 'no'}"
                          for stage in ("tcp", "auth", "connect", "https"))
        print(f"{result['endpoint']}: {stages}; {result['status']}; {result['seconds']}s")
    return 0 if results and all(result["https"] for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
