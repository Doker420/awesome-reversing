import asyncio
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

import bootstrap_google as bg


def test_accounts_format(tmp_path):
    path = tmp_path / "accounts.txt"
    path.write_text("\ufeff# private\n\nFirst@gmail.com\nsecond@gmail.com\tp:a ss\tword\n", encoding="utf-8")
    accounts = bg.read_accounts(path)
    assert accounts == [bg.Account("first@gmail.com"), bg.Account("second@gmail.com", "p:a ss\tword")]
    assert "p:a ss" not in repr(accounts)
    assert accounts[0].key == bg.Account("FIRST@gmail.com").key


@pytest.mark.parametrize("content", ["", "a@gmail.com:secret", "a@gmail.com\na@gmail.com\tsecret"])
def test_accounts_reject_invalid_without_secrets(tmp_path, content):
    path = tmp_path / "accounts.txt"
    path.write_text(content, encoding="utf-8")
    with pytest.raises(ValueError) as exc:
        bg.read_accounts(path)
    assert "secret" not in str(exc.value)


def test_proxies(tmp_path):
    (tmp_path / "b.list").write_text("host:8080\n", encoding="utf-8")
    (tmp_path / "a.txt").write_text("# comment\nhttp://user:p%40ss@[::1]:3128\n", encoding="utf-8")
    (tmp_path / "ignored.json").write_text("ignored", encoding="utf-8")
    proxies = bg.read_proxies(tmp_path)
    assert bg.playwright_proxy(proxies[0]) == {
        "server": "http://[::1]:3128", "username": "user", "password": "p@ss"}
    assert bg.playwright_proxy(proxies[1]) == {"server": "http://host:8080"}
    assert bg.account_proxy(bg.Account("a@gmail.com"), proxies) == bg.account_proxy(bg.Account("A@gmail.com"), proxies)
    assert bg.account_proxy(bg.Account("a@gmail.com"), []) is None


@pytest.mark.parametrize("proxy", ["http://user:secret@host", "http://user:secret@host:bad", "socks5://user:secret@host:0"])
def test_invalid_proxy_redacted(proxy):
    with pytest.raises(ValueError) as exc:
        bg.playwright_proxy(proxy)
    assert "secret" not in str(exc.value)


@pytest.mark.asyncio
async def test_authenticated_socks_launch_failure_closes_bridge(tmp_path, monkeypatch):
    bridges = []
    class TrackedProxy(bg.BrowserProxy):
        def __init__(self, *args):
            super().__init__(*args)
            bridges.append(self)
    monkeypatch.setattr(bg, "BrowserProxy", TrackedProxy)
    launch = AsyncMock(side_effect=RuntimeError("mock launch failure"))
    playwright = SimpleNamespace(chromium=SimpleNamespace(launch=launch))
    with pytest.raises(RuntimeError):
        await bg.collect_account(playwright, bg.Account("a@gmail.com"),
                                 ["socks5://user:proxy-secret@127.0.0.1:80"], tmp_path, True)
    assert launch.call_args.kwargs["proxy"]["server"].startswith("socks5://127.0.0.1:")
    assert "username" not in launch.call_args.kwargs["proxy"]
    assert bridges[0].server is None and not bridges[0].tasks


def test_atomic_export_and_failure_preserves_previous(tmp_path, monkeypatch):
    path = tmp_path / "cookies" / "account.json"
    cookies = [{"name": "session", "value": "test", "domain": "arena.ai"}]
    bg.atomic_export(path, cookies)
    assert json.loads(path.read_text()) == cookies
    def fail(*args):
        raise OSError("replace failed")
    monkeypatch.setattr(bg.os, "replace", fail)
    with pytest.raises(OSError):
        bg.atomic_export(path, [])
    assert json.loads(path.read_text()) == cookies
    assert list(path.parent.iterdir()) == [path]


class Locator:
    def __init__(self, visible=False, fill=None, click=None):
        self.visible = visible
        self.fill = AsyncMock(side_effect=fill)
        self.click = AsyncMock(side_effect=click)
        self.first = self

    async def is_visible(self):
        return self.visible() if callable(self.visible) else self.visible

    def or_(self, other):
        return Locator(lambda: (self.visible() if callable(self.visible) else self.visible)
                       or (other.visible() if callable(other.visible) else other.visible))


class Page:
    def __init__(self, url="https://arena.ai/", identity=True, logout=True):
        self.url = url
        self.identity = identity
        self.logout = logout
        self.goto = AsyncMock()

    def is_closed(self):
        return False

    def get_by_role(self, role, name):
        return Locator(self.logout if name.search("Log out") else False)

    def get_by_text(self, email, exact):
        assert exact
        return Locator(self.identity)

    def locator(self, selector):
        return Locator()


@pytest.mark.asyncio
@pytest.mark.parametrize("url,identity,logout,expected", [
    ("https://arena.ai/", True, True, True),
    ("https://arena.ai/", False, True, False),
    ("https://arena.ai/", True, False, False),
    ("https://arena.ai/auth/callback", True, True, False),
    ("https://accounts.google.com/", True, True, False),
    ("https://arena.ai.evil.test/", True, True, False),
])
async def test_verification(url, identity, logout, expected):
    assert await bg.arena_authenticated(Page(url, identity, logout), "a@gmail.com") is expected


@pytest.mark.asyncio
@pytest.mark.parametrize("password", ["secret", ""])
async def test_popup_normal_fields_and_cookie_scope(password):
    arena = Page(identity=False, logout=False)
    google = Page("https://accounts.google.com/signin")
    submitted = []
    def completed(*args, **kwargs):
        arena.identity = arena.logout = True
    controls = {
        'input[type="email"]': Locator(True, fill=lambda value, **kwargs: submitted.append(value)),
        "#identifierNext": Locator(True, click=completed if not password else None),
        'input[type="password"]': Locator(True, fill=lambda value, **kwargs: submitted.append(value)),
        "#passwordNext": Locator(True, click=completed),
    }
    google.locator = lambda selector: controls[selector]
    google.get_by_role = lambda *args, **kwargs: Locator(False)
    context = SimpleNamespace(pages=[arena, google], new_page=AsyncMock(return_value=arena),
                              cookies=AsyncMock(return_value=[{"name": "session"}]))
    assert await asyncio.wait_for(bg.login_account(context, bg.Account("a@gmail.com", password)), 2)
    assert submitted == (["a@gmail.com", "secret"] if password else ["a@gmail.com"])
    context.cookies.assert_awaited_once_with([bg.ARENA_URL])


@pytest.mark.asyncio
async def test_timeout_closes_browser_and_does_not_export(tmp_path, monkeypatch):
    browser = SimpleNamespace(new_context=AsyncMock(return_value=object()), close=AsyncMock())
    playwright = SimpleNamespace(chromium=SimpleNamespace(launch=AsyncMock(return_value=browser)))
    async def waiting(*args):
        await asyncio.Event().wait()
    monkeypatch.setattr(bg, "login_account", waiting)
    with pytest.raises(asyncio.TimeoutError):
        await asyncio.wait_for(bg.collect_account(playwright, bg.Account("a@gmail.com"), [], tmp_path, False), .02)
    browser.close.assert_awaited_once()
    assert not list(tmp_path.iterdir())


@pytest.mark.asyncio
async def test_landing_page_and_security_challenge_never_export():
    arena = Page(identity=False, logout=False)
    challenge = Page("https://accounts.google.com/signin/challenge/ipp")
    challenge.get_by_role = lambda *args, **kwargs: Locator(False)
    context = SimpleNamespace(pages=[arena, challenge], new_page=AsyncMock(return_value=arena),
                              cookies=AsyncMock())
    with pytest.raises(asyncio.TimeoutError):
        await asyncio.wait_for(bg.login_account(context, bg.Account("a@gmail.com")), .02)
    context.cookies.assert_not_awaited()


@pytest.mark.asyncio
async def test_collect_verified_export(tmp_path, monkeypatch):
    cookies = [{"name": "session", "domain": "arena.ai", "value": "mock"}]
    context = object()
    browser = SimpleNamespace(new_context=AsyncMock(return_value=context), close=AsyncMock())
    launch = AsyncMock(return_value=browser)
    playwright = SimpleNamespace(chromium=SimpleNamespace(launch=launch))
    login = AsyncMock(return_value=cookies)
    monkeypatch.setattr(bg, "login_account", login)
    account = bg.Account("a@gmail.com")
    await bg.collect_account(playwright, account, ["http://user:secret@host:80"], tmp_path, False)
    assert json.loads((tmp_path / f"google_{account.key}.json").read_text()) == cookies
    login.assert_awaited_once_with(context, account)
    browser.close.assert_awaited_once()
    assert launch.call_args.kwargs == {
        "headless": False, "proxy": {"server": "http://host:80", "username": "user", "password": "secret"}}


@pytest.mark.asyncio
async def test_bootstrap_partial_failure_and_redacted_logs(tmp_path, monkeypatch, caplog):
    path = tmp_path / "accounts.txt"
    path.write_text("a@gmail.com\tsecret\nb@gmail.com\n", encoding="utf-8")
    class Manager:
        async def __aenter__(self):
            return object()
        async def __aexit__(self, *args):
            pass
    monkeypatch.setattr(bg, "async_playwright", Manager)
    monkeypatch.setenv("PROXIES_DIR", str(tmp_path / "absent"))
    collector = AsyncMock(side_effect=[RuntimeError("secret proxy-password"), None])
    monkeypatch.setattr(bg, "collect_account", collector)
    with pytest.raises(RuntimeError, match="1/2"):
        await bg.bootstrap(path, timeout=1, headless=False)
    assert collector.await_count == 2
    assert "secret" not in caplog.text and "proxy-password" not in caplog.text


@pytest.mark.asyncio
@pytest.mark.parametrize("fails", [False, True])
async def test_runner_bootstraps_before_services(monkeypatch, fails):
    import run
    order = []
    async def bootstrap(*args):
        order.append("bootstrap")
        if fails:
            raise RuntimeError("secret")
    async def api(**kwargs):
        order.append("api")
    monkeypatch.setattr(bg, "bootstrap", bootstrap)
    monkeypatch.setattr(run, "run_api", api)
    monkeypatch.setattr(run.os, "makedirs", lambda *args, **kwargs: None)
    monkeypatch.setattr(run.sys, "argv", ["run.py", "--api", "--bootstrap-google"])
    if fails:
        with pytest.raises(SystemExit) as exc:
            await run.main()
        assert exc.value.code == 1
    else:
        await run.main()
    assert order == (["bootstrap"] if fails else ["bootstrap", "api"])
