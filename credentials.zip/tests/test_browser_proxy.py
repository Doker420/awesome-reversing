import asyncio
from contextlib import asynccontextmanager
from types import SimpleNamespace
from unittest.mock import AsyncMock
from urllib.parse import urlparse

import pytest

import arena_generator as ag
import browser_proxy as bp


@asynccontextmanager
async def mock_upstream(mode="ok"):
    observations = []
    tasks = set()

    async def serve(reader, writer):
        try:
            version, length = await reader.readexactly(2)
            assert version == 5
            methods = await reader.readexactly(length)
            assert 2 in methods
            writer.write(b"\x05\x02" if mode != "malformed" else b"\x04\x02")
            await writer.drain()
            if mode == "malformed":
                return
            version, length = await reader.readexactly(2)
            username = await reader.readexactly(length)
            length = (await reader.readexactly(1))[0]
            password = await reader.readexactly(length)
            observations.append((version, username, password))
            if mode == "stall":
                await reader.read()
                return
            writer.write(b"\x01\x01" if mode == "reject" else b"\x01\x00")
            await writer.drain()
            if mode == "reject":
                return
            assert await reader.readexactly(4) == b"\x05\x01\x00\x03"
            length = (await reader.readexactly(1))[0]
            host = await reader.readexactly(length)
            port = int.from_bytes(await reader.readexactly(2), "big")
            observations.append((host, port))
            writer.write(b"\x05\x00\x00\x01\x7f\x00\x00\x01\x00\x01")
            await writer.drain()
            if mode == "http":
                await reader.readuntil(b"\r\n\r\n")
                writer.write(b"HTTP/1.1 200 OK\r\nContent-Length: 14\r\nConnection: close\r\n\r\noffline bridge")
                await writer.drain()
                return
            while True:
                data = await reader.read(65536)
                if not data:
                    writer.write(b"tail")
                    await writer.drain()
                    return
                writer.write(data)
                await writer.drain()
        finally:
            await bp.close_writer(writer)

    def accept(reader, writer):
        task = asyncio.create_task(serve(reader, writer))
        tasks.add(task)
        task.add_done_callback(tasks.discard)

    server = await asyncio.start_server(accept, "127.0.0.1", 0)
    try:
        yield f"socks5://u%40ser:p%3Ass@127.0.0.1:{server.sockets[0].getsockname()[1]}", observations
    finally:
        server.close()
        await server.wait_closed()
        for task in list(tasks):
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


async def client(options):
    parsed = urlparse(options["server"])
    return await asyncio.open_connection(parsed.hostname, parsed.port)


async def connect_request(reader, writer):
    writer.write(b"\x05\x01\x00")
    await writer.drain()
    assert await reader.readexactly(2) == b"\x05\x00"
    host = b"offline.invalid"
    writer.write(b"\x05\x01\x00\x03" + bytes([len(host)]) + host + b"\x01\xbb")
    await writer.drain()
    return await reader.readexactly(10)


async def test_auth_forward_half_close_and_cleanup():
    async with mock_upstream() as (url, seen):
        bridge = bp.BrowserProxy(url)
        async with bridge as options:
            assert set(options) == {"server"}
            assert bridge.server.sockets[0].getsockname()[0] == "127.0.0.1"
            reader, writer = await client(options)
            try:
                assert (await connect_request(reader, writer))[1] == 0
                payload = b"offline payload" * 10000
                writer.write(payload)
                await writer.drain()
                assert await asyncio.wait_for(reader.readexactly(len(payload)), 3) == payload
                writer.write_eof()
                assert await asyncio.wait_for(reader.read(), 3) == b"tail"
                assert seen == [(1, b"u@ser", b"p:ss"), (b"offline.invalid", 443)]
            finally:
                await bp.close_writer(writer)
        assert bridge.server is None and not bridge.tasks
        with pytest.raises(OSError):
            await client(options)
        await bridge.close()


@pytest.mark.parametrize("mode", ["reject", "malformed", "stall"])
async def test_upstream_failure_closed(mode, caplog):
    async with mock_upstream(mode) as (url, _):
        async with bp.BrowserProxy(url, timeout=.15) as options:
            reader, writer = await client(options)
            try:
                reply = await asyncio.wait_for(connect_request(reader, writer), 2)
                assert reply[1] != 0
                assert await asyncio.wait_for(reader.read(), 2) == b""
            finally:
                await bp.close_writer(writer)
    assert "p:ss" not in caplog.text and "u@ser" not in caplog.text


@pytest.mark.parametrize("payload", [b"\x04\x01\x00", b"\x05\x00", b"\x05"])
async def test_local_malformed_or_incomplete_handshake(payload):
    bridge = bp.BrowserProxy("socks5://user:pass@127.0.0.1:1", timeout=.1)
    async with bridge as options:
        reader, writer = await client(options)
        writer.write(payload)
        await writer.drain()
        assert (await asyncio.wait_for(reader.read(), 2))[1] != 0
        await bp.close_writer(writer)
    assert not bridge.tasks


async def test_close_cancels_active_connections():
    async with mock_upstream() as (url, _):
        bridge = bp.BrowserProxy(url)
        options = await bridge.start()
        reader, writer = await client(options)
        assert (await connect_request(reader, writer))[1] == 0
        await asyncio.wait_for(bridge.close(), 2)
        assert not bridge.tasks
        assert await asyncio.wait_for(reader.read(), 2) == b""
        await bp.close_writer(writer)


async def test_close_cancels_inflight_upstream_handshake():
    async with mock_upstream("stall") as (url, seen):
        bridge = bp.BrowserProxy(url)
        options = await bridge.start()
        reader, writer = await client(options)
        request = asyncio.create_task(connect_request(reader, writer))
        try:
            async def authenticated():
                while not seen:
                    await asyncio.sleep(.01)
            await asyncio.wait_for(authenticated(), 2)
            await asyncio.wait_for(bridge.close(), 2)
            assert not bridge.tasks
            with pytest.raises(asyncio.IncompleteReadError):
                await request
        finally:
            request.cancel()
            await asyncio.gather(request, return_exceptions=True)
            await bp.close_writer(writer)
            await bridge.close()


async def test_unreachable_upstream_never_connects_direct():
    server = await asyncio.start_server(lambda *args: None, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    server.close()
    await server.wait_closed()
    async with bp.BrowserProxy(f"socks5://user:pass@127.0.0.1:{port}", timeout=.2) as options:
        reader, writer = await client(options)
        try:
            assert (await asyncio.wait_for(connect_request(reader, writer), 2))[1] != 0
            assert await asyncio.wait_for(reader.read(), 2) == b""
        finally:
            await bp.close_writer(writer)


@pytest.mark.parametrize("url,expected", [
    (None, None),
    ("host:8080", {"server": "http://host:8080"}),
    ("https://user:p%40ss@[::1]:443", {"server": "https://[::1]:443", "username": "user", "password": "p@ss"}),
    ("socks5://host:1080", {"server": "socks5://host:1080"}),
])
async def test_native_proxy_unchanged(url, expected, monkeypatch):
    listener = AsyncMock()
    monkeypatch.setattr(bp.asyncio, "start_server", listener)
    async with bp.BrowserProxy(url) as options:
        assert options == expected
    listener.assert_not_called()


@pytest.mark.parametrize("url", ["socks5://user:secret@host:bad", "ftp://user:secret@host:80",
                                     "socks5://user:secret@host", "socks5://user:secret@host:65536"])
def test_invalid_proxy_redacted(url):
    with pytest.raises(ValueError) as exc:
        bp.playwright_proxy(url)
    assert "secret" not in str(exc.value)


@pytest.mark.parametrize("stage", ["bridge", "start", "launch", "context", "page", "script", "cancel"])
async def test_failed_init_cleans_partial_resources(stage, monkeypatch, tmp_path):
    monkeypatch.setattr(ag, "COOKIES_DIR", str(tmp_path))
    monkeypatch.setattr(ag, "COOKIES_PATH", str(tmp_path / "missing.json"))
    monkeypatch.setattr(ag, "PROXIES_DIR", str(tmp_path))
    page = SimpleNamespace(add_init_script=AsyncMock())
    context = SimpleNamespace(new_page=AsyncMock(return_value=page), close=AsyncMock())
    browser = SimpleNamespace(new_context=AsyncMock(return_value=context), close=AsyncMock())
    playwright = SimpleNamespace(chromium=SimpleNamespace(launch=AsyncMock(return_value=browser)), stop=AsyncMock())
    start = AsyncMock(return_value=playwright)
    monkeypatch.setattr(ag, "async_playwright", lambda: SimpleNamespace(start=start))
    bridges = []
    class TrackedProxy(bp.BrowserProxy):
        def __init__(self, *args):
            super().__init__(*args)
            bridges.append(self)
    monkeypatch.setattr(ag, "BrowserProxy", TrackedProxy)
    if stage == "bridge":
        monkeypatch.setattr(bp.asyncio, "start_server", AsyncMock(side_effect=OSError("bind failed")))
    else:
        method = {"start": start, "launch": playwright.chromium.launch, "context": browser.new_context,
                  "page": context.new_page, "script": page.add_init_script, "cancel": browser.new_context}[stage]
        method.side_effect = asyncio.CancelledError() if stage == "cancel" else RuntimeError("offline failure")
    gen = ag.ArenaGenerator()
    gen.stealth = None
    gen._proxy_urls = ["socks5://user:pass@127.0.0.1:1"]
    with pytest.raises((OSError, RuntimeError, asyncio.CancelledError)):
        await gen.init_browser()
    assert gen.playwright is gen.browser is gen.context is gen.page is gen._browser_proxy is None
    assert bridges[0].server is None and not bridges[0].tasks
    if stage not in ("bridge", "start"):
        playwright.stop.assert_awaited_once()
    if stage in ("context", "page", "script", "cancel"):
        browser.close.assert_awaited_once()
    if stage in ("page", "script"):
        context.close.assert_awaited_once()
    await gen.close_browser()


async def test_cleanup_awaits_tasks_and_continues_after_close_error():
    gen = ag.ArenaGenerator()
    finished = asyncio.Event()
    async def pending():
        try:
            await asyncio.Event().wait()
        finally:
            finished.set()
    task = asyncio.create_task(pending())
    await asyncio.sleep(0)
    gen._response_tasks.add(task)
    gen.context = SimpleNamespace(close=AsyncMock(side_effect=RuntimeError("mock")))
    browser = gen.browser = SimpleNamespace(close=AsyncMock())
    playwright = gen.playwright = SimpleNamespace(stop=AsyncMock())
    bridge = gen._browser_proxy = bp.BrowserProxy(None)
    await gen.close_browser()
    assert finished.is_set() and task.done()
    browser.close.assert_awaited_once()
    playwright.stop.assert_awaited_once()
    assert bridge.closing and not gen._response_tasks


async def test_rotation_replaces_bridge(monkeypatch, tmp_path):
    page = SimpleNamespace(add_init_script=AsyncMock(), on=lambda *args: None)
    contexts = [SimpleNamespace(new_page=AsyncMock(return_value=page), close=AsyncMock(),
                                on=lambda *args: None) for _ in range(2)]
    browsers = [SimpleNamespace(new_context=AsyncMock(return_value=context), close=AsyncMock())
                for context in contexts]
    playwright = SimpleNamespace(chromium=SimpleNamespace(launch=AsyncMock(side_effect=browsers)), stop=AsyncMock())
    monkeypatch.setattr(ag, "async_playwright", lambda: SimpleNamespace(start=AsyncMock(return_value=playwright)))
    gen = ag.ArenaGenerator()
    gen.stealth = None
    gen._cookie_paths = [str(tmp_path / "missing.json")]
    gen._proxy_urls = ["socks5://user:pass@127.0.0.1:1", "socks5://user:pass@127.0.0.1:2"]
    await gen.init_browser()
    old = gen._browser_proxy
    old_options = playwright.chromium.launch.call_args.kwargs["proxy"]
    try:
        await gen.rotate_resource()
        assert old.server is None and not old.tasks
        assert gen._browser_proxy is not old and gen._browser_proxy.server is not None
        assert gen._active_proxy.endswith(":2")
        with pytest.raises(OSError):
            await client(old_options)
    finally:
        await gen.close_browser()
    assert all(browser.close.await_count == 1 for browser in browsers)


async def test_real_chromium_uses_bridge_offline():
    from playwright.async_api import async_playwright
    from pathlib import Path
    async with async_playwright() as playwright:
        if not Path(playwright.chromium.executable_path).exists():
            pytest.skip("Chromium binary not installed")
        async with mock_upstream("http") as (url, seen):
            bridge = bp.BrowserProxy(url)
            async with bridge as options:
                browser = await playwright.chromium.launch(headless=True, proxy=options)
                try:
                    page = await browser.new_page()
                    await page.goto("http://offline.invalid/", timeout=10000)
                    assert await page.text_content("body") == "offline bridge"
                    assert (1, b"u@ser", b"p:ss") in seen
                    assert (b"offline.invalid", 80) in seen
                finally:
                    await browser.close()
            assert bridge.server is None and not bridge.tasks
